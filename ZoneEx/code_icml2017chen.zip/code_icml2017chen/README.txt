This code has been successfully implemented in the MATLAB R2014b platform, just running demo_code.m for a quick reference of our performance. If you use our source code, please cite the paper:

Learning to Aggregate Ordinal Labels by Maximizing Separating Width.
Guangyong Chen, Shengyu Zhang, Di Lin, Hui Huang, Pheng Ann Heng.
Proceedings of the 34th International Conference on Machine Learning (ICML), 2017. 
