function Key = crowd_ordinal(Model, varargin)
% Copyright (c) 2017 Guangyong Chen, etc.
%
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files (the
% "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject to
% the following conditions:
% 
% The above copyright notice and this permission notice shall be
% included in all copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
% MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
% NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
% LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
% OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
% WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
%
% -----------------------------------------------------------------------

% varargin: name-value pair arguments in matlab style
%       -- maxIter[default=30]: number of iterations for Gibbs sampling
%       -- burnIn[default=10]: number of burn-in samples for the Markov chain
%       -- v[default=1]: variance for the normal prior of worker reliability eta
%       -- alpha[default=1]: parameter for the Dirichlet prior of worker confusion matrices
%       -- c[default=0.1]: control parameter of the posterior regularization
%       -- l[default=1]: margin parameter
%       -- prior_A[default=[]]: prior of A
%       -- prior_B[default=[]]: prior of B
%       -- prior_n[default=[]]: prior of probd0
%       -- truncate[default=0]: whether use truncated normal distribution for eta. 0--no, 1--yes
%       -- verbose[default=1]: print nothing (verbose=0); print final (verbose=1); print iterative (verbose=2)
%
% Output:
%       -- Key.Y: predicted (deterministic) labels for the items
%       -- Key.error_rate: the prediction error rate (if provided with true_labels)
%       -- Key.soft_labels: the predicted soft labels (i.e., the posterior distribution of the item labels)
%       -- Key.NLL: Negative log likelihood for the probabilistic part
%
% Guangyong Chen @Feb 2017
%%

% -----------------------------BEGIN CODE--------------------------------
[maxIter, burnIn, lambda1, alpha, lambda2, l, A0, B0, probd0, truncate, verbose] = process_varargin(varargin,...
    'maxIter', 30, 'burnIn', 10,'lambda1', 1 , 'alpha', 1, 'lambda2',1, 'l', 1, ...
    'prior_A' ,[], 'prior_B' ,[], 'prior_n', [],'truncate', 0, 'verbose', 2);

NeibTask = Model.NeibTask;NeibWork = Model.NeibWork;L = Model.L;
Ntask = Model.Ntask; Ndom = Model.Ndom; Nwork = Model.Nwork; K = Ndom;

% set default prior parameters
phi = zeros(Ndom,K,Nwork);
logphiAve = zeros(Ndom,K,Nwork);
logomegaAve = zeros(K,Ntask);
ilm = ones(Ntask,max(K-1,1));
Y = zeros(Ntask, 1);
rate = 0.002;
%for taking average
ans_soft_labels = zeros(Ntask, K);
phic = zeros(Ndom,K,Nwork);
etak = zeros(maxIter-burnIn, K-1,Nwork);
bk = zeros(maxIter-burnIn, K-1,K);
count = 0;
alpha = ones(1,Nwork);
beta = ones(1,Ntask);
%stacking vector of input to fit the model
X = zeros(Ntask,K, Nwork);
for i = 1:Ntask
    for j = NeibTask{i}
        X(i,L(i,j),j)=1;
    end
end

%initializing by mojority voting
for i = 1 : Ntask
    ct = zeros(Ndom,1);
    for d = 1 : Ndom, ct(d) = nnz(L(i,:)==d); end
    ctt = find(ct == max(ct));
    Y(i) = ctt(1);
end

%timer
tc = 0;
tic;
b = ones(K-1,K);
eta = ones(K-1,Nwork);
%learning with gibbs sampling
for iter = 1 : maxIter
    tic;
    % disp('sample a');
    
    toc1 = toc;
    % data replication
    for t = 1 : K-1
        mu = zeros(1, Nwork); Sigma = b(t,:)*b(t,:)'*eye(Nwork)./lambda1;
        for i = 1 : Ntask
            dx = zeros(1,Nwork);
            Xtmp = (reshape(X(i,:,:),[size(X(i,:,:),2),size(X(i,:,:),3)]))';
            z = sign(Y(i)-t-0.1);%2*Y(i)-3;%sign(Y(i)-t+0.1);%
            dx(1,:) = z*Xtmp*b(t,:)';
            Sigma = Sigma + (dx'*dx ) * ilm(i,t) * lambda2^2;
            mu = mu + (l* ilm(i,t) + 1/lambda2) * dx * lambda2^2;
        end
        
        eta(t,:) =mvnrnd(mu/Sigma,inv(Sigma));
    end
    
    
    
    toc1 = toc;
    % disp('sample b');
    for t = 1 : K-1
        mu = zeros(1, K); Sigma = eta(t,:)*eta(t,:)'*eye(K)./lambda1;   
        for i = 1 : Ntask
            dx = zeros(1,K);
            Xtmp = (reshape(X(i,:,:),[size(X(i,:,:),2),size(X(i,:,:),3)]))';
            z =sign(Y(i)-t-0.1);% 2*Y(i)-3;%sign(Y(i)-t+0.1);
            dx(1,:) = z*eta(t,:)*Xtmp;
            Sigma = Sigma + (dx'*dx ) * ilm(i,t) * lambda2^2;
            mu = mu + (l* ilm(i,t) + 1/lambda2) * dx * lambda2^2;
        end   
        
        b(t,:) =mvnrnd(mu/Sigma,inv(Sigma));
    end

    
    toc2 = toc;
    
    %  disp('sample phi');
    for j = 1:Nwork
        probd = ones(Ndom,K,j).* alpha(j);
    end
    for i = 1 : Ntask
        for j = NeibTask{i}
            probd(L(i,j),Y(i),j) = probd(L(i,j),Y(i),j) + 1;
        end
    end
    
    for k = 1 : K
        for j = 1 : Nwork
            phi(:,k,j) = drchrnd(probd(:,k,j)',1)+eps;
            logphiAve(:,k,j) =  ((iter-1)*logphiAve(:,k,j) +  log(phi(:,k,j)))/iter;
        end
    end
    
    
    %  disp('sample omega');
    for i = 1:Ntask
        probOmega = ones(K,i).* beta(i);
    end
    for i = 1 : Ntask
        probOmega(Y(i),i) = probOmega(Y(i),i) + 1;
    end
   
    for j = 1 : Ntask
        omega(:,j) = drchrnd(probOmega(:,j)',1)+eps;
        logomegaAve(:,j) = ((iter-1)*logomegaAve(:,j) + log(omega(:,j)))/iter;
    end
    
    
    
    toc3 = toc;
    
    % disp('sample lm');
    for i = 1 : Ntask
        dx = zeros(1,Nwork);
        Xtmp = (reshape(X(i,:,:),[size(X(i,:,:),2),size(X(i,:,:),3)]))';
        % data replication
        for t = 1 : K-1
            z = sign(Y(i)-t-0.1);%2*Y(i)-3;%sign(Y(i)-t+0.1);
            dx(1,:) = z*Xtmp*b(t,:)';
            aczetai = abs( lambda2 * (l - eta(t,:)*dx' ) +eps);
            ilm(i,t) = invnrnd(1/aczetai,1);
        end
    end
    
    toc4=toc;
    
    %   disp('sample Y');
    for i = randperm(Ntask);
        logprob = zeros(K,1);
        for k = 1 : K
            % data replication
            for t = 1 : K-1
                if ilm(i,t)~= 0
                    dx = zeros(1,Nwork);
                    Xtmp = (reshape(X(i,:,:),[size(X(i,:,:),2),size(X(i,:,:),3)]))';
                    z = sign(k-t-0.1);%2*k-3;%sign(k-t+0.1);
                    dx(1,:) = z*Xtmp*b(t,:)';
                    logprob(k) = logprob(k) -0.5*ilm(i,t)*(1/ilm(i,t)+ lambda2* (l - eta(t,:)*dx') )^2;
                end
            end
            for j = NeibTask{i}
                logprob(k) = logprob(k) + log(phi(L(i,j),k,j)+eps);
            end
            logprob(k) = logprob(k) + log(omega(k,i));
        end
        
        prob = exp(logprob - max(logprob));
        
        prob = prob./sum(prob);
        
        k = find( mnrnd( 1,prob ) >0 );
        k = k(1,1);
        
        Y(i) = k;
    end
    
    toc5=toc;
    % update alpha and beta

    for j = 1:Nwork
        logtmp = logphiAve(:,:,j);
        gradAlpha = sum(logtmp(:))+K*K*((psi(K*alpha(j)))-(psi(alpha(j))));
        alpha(j) = alpha(j) -rate*gradAlpha;
        alpha(j) = max(alpha(j),0.001);
    end
    for i = 1:Ntask
        gradBeta = sum(logomegaAve(:,i))+K*((psi(K*beta(i)))-(psi(beta(i))));
        beta(i) = beta(i) -rate*gradBeta;
        beta(i) = max(beta(i),0.001);
    end
    %save for average
    if iter > burnIn
        for i = 1 : Ntask, ans_soft_labels(i,Y(i)) = ans_soft_labels(i,Y(i))+1; end
        phic = phic + phi;
        etak(count+1,:,:) = eta;
        bk(count+1,:,:) = b;
        count = count + 1;
    end
    tc = tc + toc5 - toc1;
    %  disp([toc2-toc1,toc3-toc2,toc4-toc3,toc5-toc4]);
    
    NLL = 0;
    for t = 1:Nwork
        for i = NeibWork{t}
            NLL = NLL - log(sum(phi(L(i,t),:,t)));
        end
    end
    
    if verbose > 1
        t1 = toc;
        ans_soft_labelst(:,:) = ans_soft_labels(:,:)./count;
        [Key.error_rate(iter), Key.MoreInfo.error_L1(iter), Key.MoreInfo.error_L2(iter)]=...
            cal_error_using_soft_label(ans_soft_labelst(:,:)', Model.true_labels);
        tc = tc + toc - t1;
        fprintf('%d %f %f %f\n',iter,Key.error_rate(iter),NLL,tc);
    end
    Key.MoreInfo.timeclock(iter) = tc;
end


%for m = 1 : Nwork, eta(m) = std(etak(:,m)); end
ans_soft_labels(:,:) = ans_soft_labels(:,:)./count;
[~,Y] = max(ans_soft_labels');
phi = phic./count;
eta = mean(etak,1);
b = mean(bk,1);
NLL = 0;
for k = 1 : K
    for t = 1 : Nwork
        for d = 1 : Ndom
            NLL = NLL - probd(d,k,t)*log(phi(d,k,t));
        end
    end
end

[Key.error_rate(iter), Key.MoreInfo.error_L1(iter), Key.MoreInfo.error_L2(iter)]=...
    cal_error_using_soft_label(ans_soft_labels', Model.true_labels);
if verbose > 0
    fprintf('\t--Final: L_0 error rate = %f, L_1 error rate = %f,L_2 error rate = %f NLL = %f \n'...
        ,Key.error_rate(iter),Key.MoreInfo.error_L1(iter),Key.MoreInfo.error_L2(iter), NLL);
end

Key.X = X;
Key.Y = Y';
Key.A = mu;
Key.B = Sigma;
Key.probd = probd;
Key.lm = ilm;
Key.phi = phi;
Key.eta = eta;
Key.b = b;
Key.alpha =alpha;
Key.beta = beta;
Key.NLL = NLL;
Key.soft_labels = ans_soft_labels;
return;
end

% take a sample from a dirichlet distribution
function r = drchrnd(a,n)
p = length(a);
r = gamrnd(repmat(a,n,1),1,n,p);
r = r ./ repmat(sum(r,2),1,p);
end
